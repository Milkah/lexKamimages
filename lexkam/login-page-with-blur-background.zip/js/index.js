(function() {
  /*
Inspired by https://dribbble.com/shots/1786153-Create-Account-Transparent-Form
*/


}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBQTs7OztBQUFBIiwic291cmNlc0NvbnRlbnQiOlsiIyMjXG5JbnNwaXJlZCBieSBodHRwczovL2RyaWJiYmxlLmNvbS9zaG90cy8xNzg2MTUzLUNyZWF0ZS1BY2NvdW50LVRyYW5zcGFyZW50LUZvcm1cbiMjIyJdfQ==
//# sourceURL=coffeescript